package com.lara.projectApp01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApp01Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectApp01Application.class, args);
	}

}
