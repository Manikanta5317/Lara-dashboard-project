package com.lara.projectApp02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectApp02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
