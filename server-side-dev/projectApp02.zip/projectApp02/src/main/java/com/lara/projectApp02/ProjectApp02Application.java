package com.lara.projectApp02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApp02Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectApp02Application.class, args);
	}

}
